from .lunofetch import main
__all__ = ["main"]
